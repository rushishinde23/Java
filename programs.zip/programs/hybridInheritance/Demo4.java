package hybridInheritance;

class Parent{

}
class Child extends Parent {

}
class GrandChild extends Child {

}

class Child2 extends Parent{

}

public class Demo4 {

}
