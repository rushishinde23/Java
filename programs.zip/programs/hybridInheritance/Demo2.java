package hybridInheritance;

class A{

}

class B extends A{

}
class C extends B{

}
class D extends A{

}

public class Demo2 {
}
