package hybridInheritance;

class Vehicle{
    public void type(){
        System.out.println("Inside vehicle");
    }
}

class Car extends Vehicle{
    public void type(){
        System.out.println("Inside car");
    }
}

class TataNexon extends Car{

    public void type(){
        System.out.println("Inside nexon");
    }
}

class Bike extends Vehicle{

    public void type(){
        System.out.println("on the bike");
    }
}


public class Demo1 {
    public static void main(String[] args) {
        Vehicle v1=new Car();
        Vehicle v2=new Bike();
        Vehicle v3=new TataNexon();

        v1.type();
        v2.type();
        v3.type();
    }
}
