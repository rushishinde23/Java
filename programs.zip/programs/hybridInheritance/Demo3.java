package hybridInheritance;

class Animal{

}
class Cat extends Animal {

}
class Kiten extends Cat {

}
class Dog extends Animal{

}

public class Demo3 {
}

