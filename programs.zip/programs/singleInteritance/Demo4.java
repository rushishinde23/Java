package singleInteritance;

class Parent{

}
class Child extends Parent{

}

public class Demo4 {

}
