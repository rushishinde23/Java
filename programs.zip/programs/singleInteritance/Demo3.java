package singleInteritance;

class Animal{

}
class Cat extends Animal{

}

public class Demo3 {
}
