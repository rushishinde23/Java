package singleInteritance;

class A{

}
class B extends A{

}

public class Demo2 {
}
