package multilevelInheritance;

class Parent{

}
class Child extends Parent {

}
class GrandChild extends Child{

}

public class Demo4 {

}
