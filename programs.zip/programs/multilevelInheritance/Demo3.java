package multilevelInheritance;

class Animal{

}
class Cat extends Animal {

}
class Kiten extends Cat{

}

public class Demo3 {
}
