package multilevelInheritance;

class A{

}
class B extends A {

}
class C extends B {

}

public class Demo2 {
}
