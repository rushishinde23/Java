package multilevelInheritance;

class Vehicle{
    public void drive(){
        System.out.println("inside vehicle");
    }
    public void type(){
        System.out.println("its transportation vehicle");
    }
}

class Car extends Vehicle {

    @Override
    public void drive() {
        System.out.println("Inside Car");
    }

}

class TataNexon extends Car{

    @Override
    public void drive(){
        System.out.println("inside NEXON");
    }

}



public class Demo1 {
    public static void main(String[] args) {

        TataNexon tn=new TataNexon();
        tn.drive();
        tn.type();
    }

}
