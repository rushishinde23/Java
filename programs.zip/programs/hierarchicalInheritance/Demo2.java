package hierarchicalInheritance;

class A{

}
class B extends A{

}
class C extends A{

}
class D extends A{

}

public class Demo2 {
}
