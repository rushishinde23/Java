package hierarchicalInheritance;

class Vehicle{
    public void type(){
        System.out.println("it is vehicle");
    }
}

class Car extends Vehicle{
    @Override
    public void type(){
        System.out.println("Inside car");
    }
}

class Bike extends Vehicle{

    public void type(){
        System.out.println("on the bike");
    }
}

class Bicycle extends Car{

    public void type(){
        System.out.println("on the bicycle");
    }
}

public class Demo1 {
    public static void main(String[] args) {

        Vehicle v1=new Car();
        Vehicle v2=new Bike();
        Vehicle v3=new Bicycle();

        v1.type();
        v2.type();
        v3.type();

    }
}
