package hierarchicalInheritance;

class Animal{

}
class Cat extends Animal {

}
class Dog extends Animal{

}
class Cow extends Animal{

}

public class Demo3 {
}
