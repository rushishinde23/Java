package hierarchicalInheritance;

class Parent{

}
class Child1 extends Parent {

}
class Child2 extends Parent {

}
class Child3 extends Parent {

}

public class Demo4 {

}
